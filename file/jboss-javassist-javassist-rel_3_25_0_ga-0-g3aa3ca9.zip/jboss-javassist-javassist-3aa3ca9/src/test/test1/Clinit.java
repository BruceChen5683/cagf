package test1;

public class Clinit {
    public int i = 123;
    public static int j = 456;

    public int run() { return j; }
}
