package test3;

public class CheckModify {
    int i;
}
