package test2;

public class AddLocalVar {
    public int foo() {
        int j = 1;
        return j;
    }
}
