public class HelloWorld {
    public void print() {
        System.out.println("hello world");
    }
}
